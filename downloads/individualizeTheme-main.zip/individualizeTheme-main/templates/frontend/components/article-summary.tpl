{**
 * Article summary
 *
 * Used in issue tables of content, search results, and when browsing
 * by category. Accepts a number of params to modify behavior.
 *
 * @param Submission article
 * @param Publication publication (Optional) The version of the article
 *   to display. Default: $article->getCurrentPublication()
 * @param Context context (Optional) The context of this article.
 *   Default: $currentContext
 * @param string heading (Optional) The heading level to use for the
 *  title (eg - <h2>). Default: h2
 * @param bool cover (Optional) Whether or not to display the article
 *   cover image. Default: false
 * @param bool galleys (Optional) Whether or not to display the galley
 *   links. Default: false
 * @param bool abstract (Optional) Whether or not to show a snippet of
 *   the abstract. Default: false
 *}

{if !$heading}
  {assign var="heading" value="h2"}
{/if}
{if !$context}
  {assign var="context" value=$currentContext}
{/if}
{if !$publication}
  {assign var="publication" value=$article->getCurrentPublication()}
{/if}

<div class="
  article-summary
  {if $cover}
    article-summary-with-cover
  {/if}
">
  {if $cover && $publication->getLocalizedData('coverImage')}
    {assign var="coverImage" value=$publication->getLocalizedData('coverImage')}
    <img
      class="article-summary-cover"
      src="{$publication->getLocalizedCoverImageUrl($article->getData('contextId'))|escape}"
      alt="{$coverImage.altText|escape|default:''}"
    >
  {else}
    <div>{* Empty on purpose *}</div>
  {/if}
  <div class="article-summary-inner">
    <div class="article-summary-content">
      <a
        class="article-summary-link tab-focus"
        href="{url journal=$context->getPath() page="article" op="view" path=$article->getBestId()}"
      >
        <{$heading} class="article-summary-title">
          {$publication->getLocalizedFullTitle()|strip_unsafe_html}
        </{$heading}>
        <div class="article-summary-authors">
          {if $authorUserGroups}
            {$publication->getAuthorString($authorUserGroups)|escape}
          {else}
            {$publication->getShortAuthorString()|escape}
          {/if}
        </div>
      </a>
      {if $abstract && $publication->getLocalizedData('abstract')}
        <div class="article-summary-abstract html-text" data-reveal data-height="12">
          {$publication->getLocalizedData('abstract')|strip_unsafe_html}
        </div>
      {/if}
    </div>

    {if $galleys && $article->getGalleys()|@count}
      {th_filter_galleys
        assign="primaryGalleys"
        galleys=$article->getGalleys()
        genreIds=$primaryGenreIds
        remotes=true
      }
      {if $primaryGalleys|count}
        <div class="article-summary-galleys">
          {foreach from=$primaryGalleys item="galley"}
            {capture assign="galleyUrl"}{strip}
              {if $galley->getData('urlRemote')}
                {$galley->getData('urlRemote')}
              {else}
                {url page="article" op="view" path=$article->getBestId()|to_array:$galley->getBestGalleyId()}
              {/if}
            {/strip}{/capture}
            <a
              class="button article-summary-galley"
              href="{$galleyUrl}"
              aria-label="{translate
                key="submission.representationOfTitle"
                representation=$galley->getGalleyLabel()|escape
                title=$publication->getLocalizedFullTitle()|escape
              }"
            >
              {if $galley->isPdfGalley()}
                {include file="frontend/icons/download.svg"}
              {/if}
              <span class="button-truncate-text">
                {$galley->getGalleyLabel()|escape}
              </span>
            </a>
          {/foreach}
        </div>
      {/if}
    {/if}
  </div>
</div>